
SMODS.Voucher {
    key = 'random_voucher',
    pos = { x = 2, y = 0 },
    config = { 
        extra = {
            hands0_min = NaN,
            hands0_max = 3,
            discards0_min = NaN,
            discards0_max = 3
        } 
    },
    loc_txt = {
        name = 'Random voucher',
        text = {
            [1] = 'Plus {X:red,C:white}???{} hands, plus {X:red,C:white}???{} discards'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + pseudorandom('RANGE:0|3', 0, 3)
        ease_hands_played(pseudorandom('RANGE:0|3', 0, 3))
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + pseudorandom('RANGE:0|3', 0, 3)
        ease_discard(pseudorandom('RANGE:0|3', 0, 3))
    end
}