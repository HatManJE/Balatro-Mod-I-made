
SMODS.Back {
    key = 'hardest_deck',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            voucher_slots0 = 0
        },
    },
    loc_txt = {
        name = 'Hardest Deck',
        text = {
            [1] = '{C:red}-2{} hands and discards, vouchers no longer appear in the shop.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands - 2
        G.GAME.starting_params.hands = G.GAME.starting_params.hands - 2
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    local current_voucher_slots = (G.GAME.modifiers.extra_vouchers or 0)
                    local target_voucher_slots = 0
                    local difference = target_voucher_slots - current_voucher_slots
                    SMODS.change_voucher_limit(difference)
                    return true
                end
            }))
        }
    end
}