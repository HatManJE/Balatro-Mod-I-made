
SMODS.Back {
    key = 'finale_deck',
    pos = { x = 8, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 2,
            hand_size0 = 1
        },
    },
    loc_txt = {
        name = 'Finale Deck',
        text = {
            [1] = '{C:red}-1{} hand size when a blind is selected. x2 blind requirements.'
        },
    },
    unlocked = false,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.setting_blind then
            return {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        G.hand:change_size(-1)
                        return true
                    end
                }))
            }
        end
    end,
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 2
                return true
            end
        }))
    end
}