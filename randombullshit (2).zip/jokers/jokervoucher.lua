
SMODS.Joker{ --Joker Voucher
    key = "jokervoucher",
    config = {
        extra = {
            Xmoney = 1,
            booster_slots0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Joker Voucher',
        ['text'] = {
            [1] = 'Infinite vouchers in the shop (creates extra slot when you use a booster pack), {X:attention,C:white}X1${} at the end of round, increase by {X:attention,C:white}X1${} when opening a booster pack.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_defaults_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Xmoney}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.open_booster  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Booster Slots", colour = G.C.BLUE})
                    
                    SMODS.change_booster_limit(1)
                    return true
                end,
                extra = {
                    func = function()
                        card.ability.extra.Xmoney = (card.ability.extra.Xmoney) + 1
                        return true
                    end,
                    colour = G.C.GREEN
                }
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars * card.ability.extra.Xmoney
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(card.ability.extra.Xmoney), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}