
SMODS.Joker{ --Own Jone
    key = "ownjone",
    config = {
        extra = {
            hypermult_n0 = 2,
            hypermult_arrows0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Own Jone',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}^^^2{} Mult if played hand is a flush'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Flush"]) then
                return {
                    hypermult = {
                        3,
                        2
                    }
                }
            end
        end
    end
}