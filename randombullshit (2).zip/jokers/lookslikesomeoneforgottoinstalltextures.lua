
SMODS.Joker{ --Looks like someone forgot to install textures
    key = "lookslikesomeoneforgottoinstalltextures",
    config = {
        extra = {
            hypermult_n0 = 3,
            hypermult_arrows0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Looks like someone forgot to install textures',
        ['text'] = {
            [1] = '{X:mult,C:white}^^3{} Mult if hand contains 3 or less cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.full_hand) <= to_big(3) then
                return {
                    hypermult = {
                        2,
                        3
                    }
                }
            end
        end
    end
}