
SMODS.Joker{ --Pixel Joker
    key = "pixeljoker",
    config = {
        extra = {
            Multiplichipmult = 8
        }
    },
    loc_txt = {
        ['name'] = 'Pixel Joker',
        ['text'] = {
            [1] = 'Gains X8 Chips and Mult whenever a 2 scores'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Multiplichipmult}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 2 then
                card.ability.extra.Multiplichipmult = (card.ability.extra.Multiplichipmult) + 8
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = card.ability.extra.Multiplichipmult,
                extra = {
                    x_chips = card.ability.extra.Multiplichipmult,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}