
SMODS.Joker{ --Home Run
    key = "homerun",
    config = {
        extra = {
            xMult = 15,
            xChips = 15,
            xMoney = 7
        }
    },
    loc_txt = {
        ['name'] = 'Home Run',
        ['text'] = {
            [1] = 'Gains {X:red,C:white}15xMult{} if you beat blind with 3 hands remaining.. If you beat the blind with 2 hands remaining, gains{X:chips,C:white}15xChips{}. If you beat the blind with 1 hand remaining, gain {X:attention,C:white}x7${} at the end of round.(currently {X:mult,C:white}x15Mult{}, {X:chips,C:white}x15Chips{}, {X:attention,C:white}x7${} at the end of round).',
            [2] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_defaults_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xMult, card.ability.extra.xChips, card.ability.extra.xMoney}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big(G.GAME.current_round.hands_left) > to_big(3) then
                return {
                    func = function()
                        card.ability.extra.xMult = (card.ability.extra.xMult) + 15
                        return true
                    end,
                    message = "XMult Upgrade!"
                }
            elseif to_big(G.GAME.current_round.hands_left) > to_big(2) then
                return {
                    func = function()
                        card.ability.extra.xChips = (card.ability.extra.xChips) + 15
                        return true
                    end,
                    message = "XMult Upgrade!"
                }
            elseif to_big(G.GAME.current_round.hands_left) > to_big(1) then
                return {
                    func = function()
                        card.ability.extra.xMoney = (card.ability.extra.xMoney) + 7
                        return true
                    end,
                    message = "XMult Upgrade!"
                }
            else
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars * card.ability.extra.xMoney
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(card.ability.extra.xMoney), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.xMult
            }
            return {
                x_chips = card.ability.extra.xChips
            }
        end
    end
}