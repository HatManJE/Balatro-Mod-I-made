
SMODS.Joker{ --The :3 Face of Doom And Despair
    key = "the3faceofdoomanddespair",
    config = {
        extra = {
            odds = 6,
            blind_size0 = 0
        }
    },
    loc_txt = {
        ['name'] = 'The :3 Face of Doom And Despair',
        ['text'] = {
            [1] = '1 in 6 chance to set blind size to 0'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_defaults_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_randombu_the3faceofdoomanddespair') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_69a0e364', 1, card.ability.extra.odds, 'j_randombu_the3faceofdoomanddespair', false) then
                    SMODS.calculate_effect({
                        func = function()
                            if G.GAME.blind.in_blind then
                                
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(0).." Blind Size", colour = G.C.GREEN})
                                G.GAME.blind.chips = G.GAME.blind.chips * 0
                                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                                G.HUD_blind:recalculate()
                                return true
                            end
                        end}, card)
                    end
                end
            end
        end
    }