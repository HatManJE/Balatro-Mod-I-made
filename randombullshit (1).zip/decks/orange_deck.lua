
SMODS.Back {
    key = 'orange_deck',
    pos = { x = 3, y = 0 },
    config = {
        no_interest = true,
    },
    loc_txt = {
        name = 'Orange Deck',
        text = {
            [1] = 'Start with {C:red}-12{} Dollars, No interest'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.dollars = -12
    end
}