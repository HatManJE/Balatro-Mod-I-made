
SMODS.Back {
    key = 'minimalist_deck',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            remove_starting_cards_count0 = 32
        },
        randomize_rank_suit = true,
    },
    loc_txt = {
        name = 'Minimalist deck',
        text = {
            [1] = 'Start with only 20 random cards'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        local destroyed_cards = {}
        local temp_hand = {}
        G.E_MANAGER:add_event(Event({
            func = function()
            for _, playing_card in ipairs(G.deck.cards) do temp_hand[#temp_hand + 1] = playing_card end
                table.sort(temp_hand,
                    function(a, b)
                        return not a.playing_card or not b.playing_card or a.playing_card < b.playing_card
                    end
                )
                pseudoshuffle(temp_hand, 12345)    
                return true
            end,
        })) 
        
        G.E_MANAGER:add_event(Event({
            func = function()
                for i = 1, 32 do destroyed_cards[#destroyed_cards + 1] = temp_hand[i]:remove()
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}