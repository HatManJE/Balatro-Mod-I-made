
SMODS.Booster {
    key = 'unknown_pack',
    loc_txt = {
        name = "Unknown Pack",
        text = {
            [1] = 'Select up to one of 5 consumables/Jokers (Spectral cards, vouchers, tarot, planets, etc.) to be used immeadietely'
        },
        group_name = "defaults_boosters"
    },
    config = { extra = 5, choose = 1 },
    cost = 9,
    weight = 0.3,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "defaults_boosters",
    draw_hand = true,
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Tarot",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("50e3c2"))
        ease_background_colour({ new_colour = HEX('50e3c2'), special_colour = HEX("9013fe"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'mega_unkown_pack',
    loc_txt = {
        name = "Mega Unkown Pack",
        text = {
            [1] = 'Select up to 2 of 6 consumables/Jokers (Spectral cards, vouchers, tarot, planets, etc.) to be used immeadietely'
        },
        group_name = "defaults_boosters"
    },
    config = { extra = 6, choose = 1 },
    cost = 15,
    weight = 0.1,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    group_key = "defaults_boosters",
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Tarot",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}
