
SMODS.Consumable {
    key = 'null',
    set = 'Planet',
    pos = { x = 2, y = 0 },
    config = { 
        extra = {
            leastplayedhandlevel = 0   
        } 
    },
    loc_txt = {
        name = 'NULL',
        text = {
            [1] = 'upgrade your most played poker hand by the amount of levels on your least played poker hand'
        }
    },
    cost = 20,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        return {
            
            local temp_played = 0
            local temp_order = math.huge
            local target_hand = 'High Card'
            for hand, value in pairs(G.GAME.hands) do 
                if value.played > temp_played and value.visible then
                    temp_played = value.played
                    temp_order = value.order
                    target_hand = hand
                elseif value.played == temp_played and value.visible then
                    if value.order < temp_order then
                        temp_order = value.order
                        target_hand = hand
                    end
                end
            end
        )
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                play_sound('tarot1')
                card:juice_up(0.8, 0.5)
                G.TAROT_INTERRUPT_PULSE = true
                return true
            end
        }))
        update_hand_text({ delay = 0 }, { mult = '+', StatusText = true })
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.9,
            func = function()
                play_sound('tarot1')
                card:juice_up(0.8, 0.5)
                return true
            end
        }))
        update_hand_text({ delay = 0 }, { chips = '+', StatusText = true })
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.9,
            func = function()
                play_sound('tarot1')
                card:juice_up(0.8, 0.5)
                G.TAROT_INTERRUPT_PULSE = nil
                return true
            end
        }))
    update_hand_text({ sound = 'button', volume = 0.7, pitch = 0.9, delay = 0 }, { level = '+'..tostring((function() local least_played = math.huge; local least_played_hand = ''; for hand, data in pairs(G.GAME.hands) do if data.played < least_played then least_played = data.played; least_played_hand = hand end end; return least_played_hand ~= '' and G.GAME.hands[least_played_hand].level or 0 end)()) })
    delay(1.3)
level_up_hand(card, "Pair", true, (function() local least_played = math.huge; local least_played_hand = ''; for hand, data in pairs(G.GAME.hands) do if data.played < least_played then least_played = data.played; least_played_hand = hand end end; return least_played_hand ~= '' and G.GAME.hands[least_played_hand].level or 0 end)())
    update_hand_text({sound = 'button', volume = 0.7, pitch = 1.1, delay = 0}, 
        {handname=localize('Pair', 'poker_hands'), 
            chips = G.GAME.hands['Pair'].chips, 
            mult = G.GAME.hands['Pair'].mult, 
        level=G.GAME.hands['Pair'].level})    
        delay(1.3)
        __PRE_RETURN_CODE_END__
    }
end,
can_use = function(self, card)
    return true
end
}