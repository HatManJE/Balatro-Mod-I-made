
SMODS.Seal {
    key = 'abandonedseal',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            blindsskipped = 0
        }
    },
    badge_colour = HEX('2b2b2b'),
    loc_txt = {
        name = 'Abandoned Seal',
        label = 'Abandoned Seal',
        text = {
            [1] = '{X:red,C:white}X0.75{} Mult per blind skipped'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {((G.GAME.skips or 0)) * 0.75}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = (G.GAME.skips) * 0.75
            }
        end
    end
}