
SMODS.Seal {
    key = 'whiteseal',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            xchips0 = 5
        }
    },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'White Seal',
        label = 'White Seal',
        text = {
            [1] = '{X:spectral,C:white}5x{} Chips'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                x_chips = 5
            }
        end
    end
}