
SMODS.Back {
    key = 'voucher_deck',
    pos = { x = 5, y = 0 },
    config = {
        extra = {
            voucher_slots0 = 3,
            booster_slots0 = 0,
            shop_slots0 = 0
        },
    },
    loc_txt = {
        name = 'Voucher Deck',
        text = {
            [1] = 'Start with 0 shop/Booster slots, gain 3 extra voucher slots, start with 25$'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.dollars = 25
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_voucher_limit(3)
                    return true
                end
            })),
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        local current_booster_slots = (G.GAME.modifiers.extra_boosters or 0)
                        local target_booster_slots = 0
                        local difference = target_booster_slots - current_booster_slots
                        SMODS.change_booster_limit(difference)
                        return true
                    end
                })),
                colour = G.C.WHITE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            local current_shop_slots = (G.GAME.modifiers.shop_size or 0)
                            local target_shop_slots = 0
                            local difference = target_shop_slots - current_shop_slots
                            change_shop_size(difference)
                            return true
                        end
                    })),
                    colour = G.C.WHITE,
                    extra = {
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.GAME.round_resets.reroll_cost = G.GAME.round_resets.reroll_cost + 1.3e+21
                                G.GAME.current_round.reroll_cost = math.max(0,
                                G.GAME.current_round.reroll_cost + 1.3e+21)
                                return true
                            end
                        }))
                        ,
                        colour = G.C.BLUE
                    }
                }
            }
        }
    end
}