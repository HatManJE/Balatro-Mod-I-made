
SMODS.Back {
    key = 'purple_deck',
    pos = { x = 4, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Purple Deck',
        text = {
            [1] = 'Start with no consumable slots'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.consumable_slots = 0
    end
}