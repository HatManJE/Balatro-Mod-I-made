
SMODS.Back {
    key = 'ice_deck',
    pos = { x = 6, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 2,
            odds = 4
        },
    },
    loc_txt = {
        name = 'Ice Deck',
        text = {
            [1] = 'half blind size, 1/4 chance to add 1 required ante after beating the boss'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if SMODS.pseudorandom_probability(card, 'group_0_8daac183', 1, card.ability.extra.odds, 'j_randombu_ice_deck', false) then
                local ante = G.GAME.win_ante + 1
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
                
            end
        end
    end,
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling / 2
                return true
            end
        }))
    end
}