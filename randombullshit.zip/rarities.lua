SMODS.Rarity {
    key = "jesterful",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "Jesterful"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}