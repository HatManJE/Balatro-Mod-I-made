
SMODS.Voucher {
    key = 'inverse',
    pos = { x = 1, y = 0 },
    loc_txt = {
        name = 'Inverse',
        text = {
            [1] = 'All consumables, wether from booster packs or the shop, have a fixed 1 in 25 chance to be negative. Additionally, if the first hand of the round contains exactly 2 cards, make one of those cards negative and destroys the other'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_Negativity'},
    atlas = 'CustomVouchers',
    
}