
SMODS.Voucher {
    key = 'negativity',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = 'Negativity',
        text = {
            [1] = 'Tarot cards from booster packs and the shop have a small chance to be {X:legendary,C:white}negative{}'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    
}