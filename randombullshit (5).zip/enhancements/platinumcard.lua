
SMODS.Enhancement {
    key = 'platinumcard',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            xchips0 = 2.5
        }
    },
    loc_txt = {
        name = 'Platinum Card',
        text = {
            [1] = '{X:chips,C:white}X2.5{} Chips when held in hand. no suit or rank'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return {
                x_chips = 2.5
            }
        end
    end
}