
SMODS.Joker{ --Dogecoin
    key = "dogecoin",
    config = {
        extra = {
            dollars0_min = NaN,
            dollars0_max = 10
        }
    },
    loc_txt = {
        ['name'] = 'Dogecoin',
        ['text'] = {
            [1] = 'Gain from 5$ to 10$ when selling a card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.selling_card  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + pseudorandom('RANGE:5|10', 5, 10)
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(pseudorandom('RANGE:5|10', 5, 10)), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}