
SMODS.Edition {
    key = 'boosted',
    shader = 'booster',
    prefix_config = {
        -- This allows using the vanilla shader
        -- Not needed when using your own
        shader = false
    },
    config = {
        extra = {
            jokercount = 0
        }
    },
    in_shop = false,
    weight = 0.1,
    extra_cost = 5,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Boosted',
        label = 'Boosted',
        text = {
            [1] = '{X:red,C:white}X1{} Mult per joker'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {#(G.jokers and (G.jokers and G.jokers.cards or {}) or {})}}
    end,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return {
                Xmult = #(G.jokers and G.jokers.cards or {})
            }
        end
    end
}