
SMODS.Seal {
    key = 'faileddeckeffect',
    pos = { x = 2, y = 0 },
    badge_colour = HEX('424242'),
    loc_txt = {
        name = 'Failed Deck Effect',
        label = 'Failed Deck Effect',
        text = {
            [1] = 'destroys itself after scoring'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = true,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            card.should_destroy = true
            return {
                message = "destroyed!"
            }
        end
    end
}