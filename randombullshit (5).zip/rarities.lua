SMODS.Rarity {
    key = "jesterful",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "Jesterful"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "deck_effect",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Deck Effect"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}