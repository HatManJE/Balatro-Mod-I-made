
SMODS.Back {
    key = 'antiantimatter_deck_sprites_missing',
    pos = { x = 3, y = 2 },
    config = {
        extra = {
            all_blinds_size0 = 6,
            remove_starting_cards_count0 = 32,
            shop_slots0 = 0,
            booster_slots0 = 0,
            voucher_slots0 = 0,
            odds = 4,
            hand_size0 = 1
        },
        remove_faces = true,
        randomize_rank_suit = true,
    },
    loc_txt = {
        name = 'AntiAntiMatter Deck (sprites missing)',
        text = {
            [1] = 'Applies de downsides of every deck. Start with 15 hands and 9 discards ( ts is probably impossible lol'
            },
        },
        unlocked = true,
        discovered = true,
        no_collection = false,
        atlas = 'CustomDecks',
        calculate = function(self, card, context)
            if context.end_of_round and context.main_eval and G.GAME.blind.boss then
                G.GAME.starting_params.hands = G.GAME.starting_params.hands - 1
                G.GAME.starting_params.hands = G.GAME.starting_params.hands - 1
                G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots - 1
                if SMODS.pseudorandom_probability(card, 'group_0_3de26c33', 1, card.ability.extra.odds, 'j_randombu_antiantimatter_deck_sprites_missing', false) then
                    local ante = G.GAME.win_ante + 1
                    local int_part, frac_part = math.modf(ante)
                    local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                    G.GAME.win_ante = rounded
                    
                end
            end
            if context.setting_blind then
                return {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            G.hand:change_size(-1)
                            return true
                        end
                    }))
                }
            end
        end,
        apply = function(self, back)
            G.E_MANAGER:add_event(Event({
                func = function()
                    G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 6
                    return true
                end
            }))
            G.GAME.starting_params.hands = 15
            G.GAME.starting_params.hands = 9
            local destroyed_cards = {}
            local temp_hand = {}
            G.E_MANAGER:add_event(Event({
                func = function()
                for _, playing_card in ipairs(G.deck.cards) do temp_hand[#temp_hand + 1] = playing_card end
                    table.sort(temp_hand,
                        function(a, b)
                            return not a.playing_card or not b.playing_card or a.playing_card < b.playing_card
                        end
                    )
                    pseudoshuffle(temp_hand, 12345)    
                    return true
                end,
            })) 
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    for i = 1, 32 do destroyed_cards[#destroyed_cards + 1] = temp_hand[i]:remove()
                    end
                    G.GAME.starting_deck_size = #G.playing_cards
                    return true
                end
            }))
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                        local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_tinyyellowdeckeffect' })
                        if new_joker then
                            new_joker:set_edition("e_negative", true)
                            new_joker:add_sticker('eternal', true)
                        end
                        G.GAME.joker_buffer = 0
                    end
                    return true
                end
            }))
            return {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        local current_shop_slots = (G.GAME.modifiers.shop_size or 0)
                        local target_shop_slots = 0
                        local difference = target_shop_slots - current_shop_slots
                        change_shop_size(difference)
                        return true
                    end
                })),
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            local current_booster_slots = (G.GAME.modifiers.extra_boosters or 0)
                            local target_booster_slots = 0
                            local difference = target_booster_slots - current_booster_slots
                            SMODS.change_booster_limit(difference)
                            return true
                        end
                    })),
                    colour = G.C.WHITE,
                    extra = {
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                
                                
                                local current_voucher_slots = (G.GAME.modifiers.extra_vouchers or 0)
                                local target_voucher_slots = 0
                                local difference = target_voucher_slots - current_voucher_slots
                                SMODS.change_voucher_limit(difference)
                                return true
                            end
                        })),
                        colour = G.C.WHITE
                    }
                }
            }
            G.GAME.starting_params.consumable_slots = 0
            G.GAME.starting_params.dollars = -12
            G.GAME.starting_params.hands = G.GAME.starting_params.hands - 3
            G.GAME.starting_params.hands = G.GAME.starting_params.hands - 2
            local ante = G.GAME.win_ante + 1
            local int_part, frac_part = math.modf(ante)
            local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
            G.GAME.win_ante = rounded
            G.E_MANAGER:add_event(Event({
                func = function()
                    for k, v in pairs(G.playing_cards) do
                        v:set_seal("randombu_faileddeckeffect", true, true)
                    end
                    G.GAME.starting_deck_size = #G.playing_cards
                    return true
                end
            }))
            G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots - 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                        local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_powerfuldeckeffectantiantimatteredition' })
                        if new_joker then
                            new_joker:set_edition("e_negative", true)
                            new_joker:add_sticker('eternal', true)
                        end
                        G.GAME.joker_buffer = 0
                    end
                    return true
                end
            }))
            return {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.interest_cap = 0
                        return true
                    end
                }))
                
            }
        end
    }