
SMODS.Back {
    key = 'tiny_red_deck',
    pos = { x = 3, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'tiny red deck',
        text = {
            [1] = 'start with 8 discards. {C:red}-1{} discard when defeating the boss blind. {C:attention}+1{} required ante'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            G.GAME.starting_params.hands = G.GAME.starting_params.hands - 1
        end
    end,
    apply = function(self, back)
        G.GAME.starting_params.hands = 8
        local ante = G.GAME.win_ante + 1
        local int_part, frac_part = math.modf(ante)
        local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
        G.GAME.win_ante = rounded
    end
}