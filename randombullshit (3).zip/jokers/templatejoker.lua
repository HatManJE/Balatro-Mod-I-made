
SMODS.Joker{ --Template joker
    key = "templatejoker",
    config = {
        extra = {
            shop_slots_increase = '1',
            Mult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Template joker',
        ['text'] = {
            [1] = 'Gains {X:red,C:white}X0.1Mult{} when buying a card from the shop. {C:red}-1{} shop slot'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Mult}}
    end,
    
    calculate = function(self, card, context)
        if context.buying_card  then
            return {
                func = function()
                    card.ability.extra.Mult = (card.ability.extra.Mult) + 0.1
                    return true
                end,
                message = "Upgrade!"
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.Mult
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        change_shop_size(-1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        change_shop_size(1)
    end
}