
SMODS.Joker{ --Squeaqs The Bunny
    key = "squeaqsthebunny",
    config = {
        extra = {
            levels0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Squeaqs The Bunny',
        ['text'] = {
            [1] = 'Level played up hand by 2 whenever a card scores'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            local target_hand = (context.scoring_name or "High Card")
            level_up_hand(card, target_hand, true, 2)
            return {
                message = localize('k_level_up_ex')
            }
        end
    end
}