
SMODS.Back {
    key = 'pink_deck',
    pos = { x = 7, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Pink Deck',
        text = {
            [1] = 'Start with 10 joker slots. lose a joker slot when boss blind is defeated'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots - 1
        end
    end,
    apply = function(self, back)
        G.GAME.starting_params.joker_slots = 10
    end
}