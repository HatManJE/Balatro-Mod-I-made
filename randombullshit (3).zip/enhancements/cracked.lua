
SMODS.Enhancement {
    key = 'cracked',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            hypermult_n0 = 1.2,
            hypermult_arrows0 = 1
        }
    },
    loc_txt = {
        name = 'Cracked',
        text = {
            [1] = '{X:mult,C:white}^^1.2{} Mult'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0.75,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                hypermult = {
                    1,
                    1.2
                }
            }
        end
    end
}