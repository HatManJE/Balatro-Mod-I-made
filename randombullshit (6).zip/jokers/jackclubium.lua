
SMODS.Joker{ --Jack Clubium
    key = "jackclubium",
    config = {
        extra = {
            consumableslots = 0
        }
    },
    loc_txt = {
        ['name'] = 'Jack Clubium',
        ['text'] = {
            [1] = 'All jacks of {C:clubs}Clubs{} double total consumable slots'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(G.consumeables and G.consumeables.config.card_limit or 0 or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 11 and context.other_card:is_suit("Clubs")) then
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({func = function()
                            G.consumeables.config.card_limit = G.consumeables.config.card_limit + G.consumeables and G.consumeables.config.card_limit or 0
                            return true
                        end }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(G.consumeables and G.consumeables.config.card_limit or 0).." Consumable Slot", colour = G.C.GREEN})
                        return true
                    end
                }
            end
        end
    end
}