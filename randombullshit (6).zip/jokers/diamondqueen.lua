
SMODS.Joker{ --Diamond Queen
    key = "diamondqueen",
    config = {
        extra = {
            dollars0 = 25
        }
    },
    loc_txt = {
        ['name'] = 'Diamond Queen',
        ['text'] = {
            [1] = 'Queens of {C:diamonds}Diamonds{} give x25$'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "randombu_jesterful",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 12 and context.other_card:is_suit("Diamonds")) then
                return {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars * 25
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(25), colour = G.C.MONEY})
                        return true
                    end
                }
            end
        end
    end
}