
SMODS.Joker{ --Dr. Spectered
    key = "drspectered",
    config = {
        extra = {
            slot_change = '900',
            discount_amount = '1',
            shop_slots_increase = '10',
            reroll_amount = '1.0000000000000003e+219',
            voucher_slots_increase = '10',
            hands_change = '9',
            discards_change = '9',
            hyperchips_n0 = 2,
            hyperchips_arrows0 = 4,
            hypermult_n0 = 2,
            hypermult_arrows0 = 4,
            dollars0 = 99,
            odds = 3,
            blind_size0 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dr. Spectered',
        ['text'] = {
            [1] = 'The truth, the legend... The best at balatro, the undeniable, unbeatable champion. Nothing could COMPARE to his intelligence, stealth, and willpower.',
            [2] = '',
            [3] = '^^^^2 Mult, ^^^^2 chips, X99$ when any card is scored, {C:attention}+900{} consumable slots, All cards in the shop slots are free, {C:attention}+10{} shop slots, all rerolls in the shop are free, all vouchers are free, {C:attention}+10{} voucher slots, {C:attention}+9{} hands and discards, and a fixed 1 / 3 chance to set the blindsize to 0.',
            [4] = '',
            [5] = '{s:0.5}{(Where am I? I was playing balatro and suddenly Im here..)}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 500,
    rarity = "randombu_dr_spectered",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_randombu_drspectered') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                hyperchips = {
                    4,
                    2
                },
                extra = {
                    hypermult = {
                        4,
                        2
                    },
                    colour = G.C.DARK_EDITION
                }
            }
        end
        if context.individual and context.cardarea == G.play  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars * 99
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(99), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.setting_blind  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_cf17235c', 1, card.ability.extra.odds, 'j_randombu_drspectered', true) then
                    SMODS.calculate_effect({
                        func = function()
                            if G.GAME.blind.in_blind then
                                
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(0).." Blind Size", colour = G.C.GREEN})
                                G.GAME.blind.chips = 0
                                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                                G.HUD_blind:recalculate()
                                return true
                            end
                        end}, card)
                    end
                end
            end
        end,
        
        add_to_deck = function(self, card, from_debuff)
            G.E_MANAGER:add_event(Event({func = function()
                G.consumeables.config.card_limit = G.consumeables.config.card_limit + 900
                return true
            end }))
            G.E_MANAGER:add_event(Event({
                func = function()
                    for k, v in pairs(G.I.CARD) do
                    if v.set_cost then v:set_cost() end
                    end
                    return true
                end
            }))
            change_shop_size(10)
            SMODS.change_free_rerolls(1.0000000000000003e+219)
            SMODS.change_voucher_limit(10)
            G.GAME.round_resets.hands = G.GAME.round_resets.hands + 9
            G.GAME.round_resets.discards = G.GAME.round_resets.discards + 9
        end,
        
        remove_from_deck = function(self, card, from_debuff)
            G.E_MANAGER:add_event(Event({func = function()
                G.consumeables.config.card_limit = G.consumeables.config.card_limit - 900
                return true
            end }))
            G.E_MANAGER:add_event(Event({
                func = function()
                    for k, v in pairs(G.I.CARD) do
                    if v.set_cost then v:set_cost() end
                    end
                    return true
                end
            }))
            change_shop_size(-10)
            SMODS.change_free_rerolls(-(1.0000000000000003e+219))
            SMODS.change_voucher_limit(-10)
            G.GAME.round_resets.hands = G.GAME.round_resets.hands - 9
            G.GAME.round_resets.discards = G.GAME.round_resets.discards - 9
        end
    }


local card_set_cost_ref = Card.set_cost
function Card:set_cost()
    card_set_cost_ref(self)
    
    if next(SMODS.find_card("j_randombu_drspectered")) then
        if (self.ability.set == 'Joker' or self.ability.set == 'Tarot' or self.ability.set == 'Planet' or self.ability.set == 'Spectral' or self.ability.set == 'Enhanced' or self.ability.set == 'Booster' or self.ability.set == 'Voucher') then
            self.cost = 0
        end
    end
    
    self.sell_cost = math.max(1, math.floor(self.cost / 2)) + (self.ability.extra_value or 0)
    self.sell_cost_label = self.facing == 'back' and '?' or self.sell_cost
end