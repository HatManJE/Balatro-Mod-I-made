
SMODS.Joker{ --Powerful Deck Effect (Antiantimatter edition)
    key = "powerfuldeckeffectantiantimatteredition",
    config = {
        extra = {
            odds = 4,
            emult0 = 0.5
        }
    },
    loc_txt = {
        ['name'] = 'Powerful Deck Effect (Antiantimatter edition)',
        ['text'] = {
            [1] = '1 in 4 chance for ^0.5 Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "randombu_deck_effect",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["randombu_randombu_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_randombu_powerfuldeckeffectantiantimatteredition') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_3353b74b', 1, card.ability.extra.odds, 'j_randombu_powerfuldeckeffectantiantimatteredition', false) then
                    SMODS.calculate_effect({e_mult = 0.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Aw Dangit!", colour = G.C.DARK_EDITION})
                end
            end
        end
    end
}