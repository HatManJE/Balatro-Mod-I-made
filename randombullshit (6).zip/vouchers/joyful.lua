
SMODS.Voucher {
    key = 'joyful',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            winner_ante_value0 = 1
        } 
    },
    loc_txt = {
        name = 'Joyful',
        text = {
            [1] = '{C:red}-1{} required ante'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        return {
            func = function()
                
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        local ante = G.GAME.win_ante - 1
                        local int_part, frac_part = math.modf(ante)
                        local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                        G.GAME.win_ante = rounded
                        return true
                    end
                }))
                return true
            end,
            message = "Winner Ante -" .. 1
        }
    end
}