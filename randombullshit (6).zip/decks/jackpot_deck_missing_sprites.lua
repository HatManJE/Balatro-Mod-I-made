
SMODS.Back {
    key = 'jackpot_deck_missing_sprites',
    pos = { x = 1, y = 2 },
    config = {
        extra = {
            repetitions = 10
        },
    },
    loc_txt = {
        name = 'Jackpot Deck (missing sprites)',
        text = {
            [1] = 'All chances are guaranted (aka. start with 10 negative eternal oops all sixes!)'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        for i = 1, 10 do
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_oopsallsixes' })
                    if new_joker then
                        new_joker:set_edition("e_negative", true)
                        new_joker:add_sticker('eternal', true)
                    end
                    return true
                end
            }))
            
        end
    end
}