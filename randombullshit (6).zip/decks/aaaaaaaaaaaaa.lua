
SMODS.Back {
    key = 'aaaaaaaaaaaaa',
    pos = { x = 1, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'AAAAAAAAAAAAA',
        text = {
            [1] = 'starts with 13 Aces of each suit.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    assert(SMODS.change_base(v, nil, '14'))
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}