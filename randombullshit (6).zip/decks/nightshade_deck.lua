
SMODS.Back {
    key = 'nightshade_deck',
    pos = { x = 6, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'NightShade Deck',
        text = {
            [1] = 'Create 3 random cards when hand is played'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_nightshadedeckeffect' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                    new_joker:add_sticker('eternal', true)
                end
                return true
            end
        }))
    end
}