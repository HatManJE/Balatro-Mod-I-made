
SMODS.Back {
    key = 'shader_deck',
    pos = { x = 1, y = 1 },
    config = {
        extra = {
            booster_slots0 = 1,
            voucher_slots0 = 1,
            shop_slots0 = 1
        },
    },
    loc_txt = {
        name = 'Shader Deck',
        text = {
            [1] = '{C:red}-1{} shop slot, {C:red}-1{} booster slot, {C:red}-1{} voucher slot. {C:attention}+1{} hand, {C:attention}+1{} discard'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_booster_limit(-1)
                    return true
                end
            })),
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        SMODS.change_voucher_limit(-1)
                        return true
                    end
                })),
                colour = G.C.WHITE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            change_shop_size(-1)
                            return true
                        end
                    })),
                    colour = G.C.WHITE
                }
            }
        }
    end
}