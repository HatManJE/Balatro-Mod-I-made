
SMODS.Back {
    key = 'nothing_deck',
    pos = { x = 4, y = 2 },
    config = {
    },
    loc_txt = {
        name = 'Nothing Deck (missing sprites',
            text = {
                [1] = 'Does nothing. Thats it. Nothing. You would think that it does something like {C:attention}+1{} consumable slot, {C:attention}+1{} required ante, or maybe even {C:attention}+2{} hands, but no, it does absolutely nothing. Nothing at all, and dont even try to find anything cool in here. It does nothing.'
            },
        },
        unlocked = true,
        discovered = true,
        no_collection = false,
        atlas = 'CustomDecks',
        
    }