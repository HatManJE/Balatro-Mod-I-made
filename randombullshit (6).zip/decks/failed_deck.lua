
SMODS.Back {
    key = 'failed_deck',
    pos = { x = 0, y = 2 },
    config = {
    },
    loc_txt = {
        name = 'Failed deck',
        text = {
            [1] = 'All cards get destroyed after scoring'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_seal("randombu_faileddeckeffect", true, true)
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}