
SMODS.Back {
    key = 'tiny_yellow_deck',
    pos = { x = 5, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Tiny yellow deck',
        text = {
            [1] = 'Start with 100 Dollars. {C:red}-10${} when beating a blind'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.dollars = 100
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_tinyyellowdeckeffect' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                    new_joker:add_sticker('eternal', true)
                end
                return true
            end
        }))
    end
}