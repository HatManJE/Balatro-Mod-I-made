
SMODS.Back {
    key = 'salmon_deck',
    pos = { x = 9, y = 0 },
    config = {
        extra = {
            item_rate0 = 0,
            item_rate = 0,
            item_rate2 = 0.5,
            item_rate3 = 0.5
        },
    },
    loc_txt = {
        name = 'Salmon Deck',
        text = {
            [1] = 'Start with an eternal negative showman. Rare jokers, legendary jokers and consumables cannot appear  in the shop slots'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_showman' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                    new_joker:add_sticker('eternal', true)
                end
                return true
            end
        }))
        G.GAME.rare_mod = 0
        G.GAME.legendary_mod = 0
        G.GAME.common_mod = 0.5
        G.GAME.uncommon_mod = 0.5
    end
}