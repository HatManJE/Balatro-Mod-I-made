
SMODS.Back {
    key = 'tiny_blue_deck',
    pos = { x = 4, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Tiny blue Deck',
        text = {
            [1] = 'Start with 9 hands. {C:red}-1{} hand when beating the boss blind.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            G.GAME.starting_params.hands = G.GAME.starting_params.hands - 1
        end
    end,
    apply = function(self, back)
        G.GAME.starting_params.hands = 9
    end
}