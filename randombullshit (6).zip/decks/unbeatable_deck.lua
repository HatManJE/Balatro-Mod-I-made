
SMODS.Back {
    key = 'unbeatable_deck',
    pos = { x = 8, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Unbeatable Deck',
        text = {
            [1] = 'You\'ll see why...'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_acorn") then
                local ante = G.GAME.win_ante + 8
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_leaf") then
                local ante = G.GAME.win_ante + 8
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_vessel") then
                local ante = G.GAME.win_ante + 8
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_heart") then
                local ante = G.GAME.win_ante + 8
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_bell") then
                local ante = G.GAME.win_ante + 8
                local int_part, frac_part = math.modf(ante)
                local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
                G.GAME.win_ante = rounded
            end
        end
    end,
    
}