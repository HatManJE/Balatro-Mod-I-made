
SMODS.Enhancement {
    key = 'crystal',
    pos = { x = 2, y = 0 },
    config = {
        mult = 4
    },
    loc_txt = {
        name = 'Crystal',
        text = {
            [1] = '{C:red}+5{} Mult, always scores'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0.5
}