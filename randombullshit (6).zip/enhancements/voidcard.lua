
SMODS.Enhancement {
    key = 'voidcard',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            mostrecenthandlevel = 0
        }
    },
    loc_txt = {
        name = 'Void Card',
        text = {
            [1] = 'doubles level for played hand, self destructs after scoring'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0.25,
    loc_vars = function(self, info_queue, card)
        return {vars = {((G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level or 0) or 0)}}
    end,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            local target_hand
            target_hand = context.scoring_name or "High Card"
            card.should_destroy = true
            return {
                level_up = (G.GAME.last_hand_played and G.GAME.hands[G.GAME.last_hand_played] and G.GAME.hands[G.GAME.last_hand_played].level or 0),
                level_up_hand = target_hand,
                message = localize('k_level_up_ex')
            }
        end
    end
}