
SMODS.Voucher {
    key = 'voucher_voucher',
    pos = { x = 3, y = 0 },
    loc_txt = {
        name = 'Voucher Voucher',
        text = {
            [1] = '{C:attention}+1{} voucher slot'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    
}