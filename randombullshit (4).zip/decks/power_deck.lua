
SMODS.Back {
    key = 'power_deck',
    pos = { x = 9, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Power Deck',
        text = {
            [1] = '{E:1}1 in 4{} chance to give ^2 Mult, 1 in 4 chance to give ^0.5 Mult'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_powerfuldeckeffect' })
                if new_joker then
                    new_joker:set_edition("e_negative", true)
                    new_joker:add_sticker('eternal', true)
                end
                return true
            end
        }))
    end
}