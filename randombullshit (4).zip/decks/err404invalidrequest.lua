
SMODS.Back {
    key = 'err404invalidrequest',
    pos = { x = 7, y = 0 },
    config = {
        extra = {
            hand_size0_min = NaN,
            hand_size0_max = 5,
            hand_size_min = NaN,
            hand_size_max = 4,
            discard_size0_min = NaN,
            discard_size0_max = 5,
            play_size0_min = NaN,
            play_size0_max = 5,
            play_size_min = NaN,
            play_size_max = 3,
            all_blinds_size0_min = NaN,
            all_blinds_size0_max = 2.5,
            all_blinds_size0_min = NaN,
            all_blinds_size0_max = 2.5,
            shop_slots0_min = NaN,
            shop_slots0_max = 11,
            voucher_slots0_min = NaN,
            voucher_slots0_max = 4,
            booster_slots0_min = NaN,
            booster_slots0_max = 5,
            item_rate0 = 1
        },
        randomize_rank_suit = true,
    },
    loc_txt = {
        name = 'ERR404://INVALIDREQUEST',
        text = {
            [1] = 'Randomizes almost everything in the game. Good luck.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + pseudorandom('RANGE:1|5', 1, 5)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands - pseudorandom('RANGE:1|2', 1, 2)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + pseudorandom('RANGE:1|5', 1, 5)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands - pseudorandom('RANGE:1|3', 1, 3)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands - pseudorandom('RANGE:1|3', 1, 3)
        G.GAME.modifiers.money_per_hand =  (G.GAME.modifiers.money_per_hand or 1) +pseudorandom('RANGE:1|5', 1, 5)
        G.GAME.modifiers.money_per_hand =  (G.GAME.modifiers.money_per_hand or 1) -pseudorandom('RANGE:1|3', 1, 3)
        G.GAME.modifiers.money_per_discard = pseudorandom('RANGE:1|5', 1, 5)
        G.GAME.starting_params.dollars = G.GAME.starting_params.dollars +pseudorandom('RANGE:1|5', 1, 5)
        G.GAME.starting_params.dollars = G.GAME.starting_params.dollars -pseudorandom('RANGE:1|5', 1, 5)
        G.GAME.starting_params.joker_slots = pseudorandom('RANGE:3|15', 3, 15)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * pseudorandom('RANGE:1|2.5', 1, 2.5)
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling / pseudorandom('RANGE:1|2.5', 1, 2.5)
                return true
            end
        }))
        G.GAME.win_ante = pseudorandom('RANGE:5|20', 5, 20)
        G.GAME._mod = G.GAME._mod + 1
        G.SETTINGS.GAMESPEED = 1
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(pseudorandom('RANGE:1|5', 1, 5))
                    return true
                end
            })),
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        G.hand:change_size(-pseudorandom('RANGE:1|4', 1, 4))
                        return true
                    end
                })),
                colour = G.C.WHITE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            
                            SMODS.change_discard_limit(pseudorandom('RANGE:1|5', 1, 5))
                            return true
                        end
                    })),
                    colour = G.C.WHITE,
                    extra = {
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.GAME.interest_cap = pseudorandom('RANGE:1|40', 1, 40)
                                return true
                            end
                        }))
                        ,
                        colour = G.C.BLUE,
                        extra = {
                            
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    
                                    
                                    SMODS.change_play_limit(pseudorandom('RANGE:1|5', 1, 5))
                                    return true
                                end
                            })),
                            colour = G.C.WHITE,
                            extra = {
                                
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        
                                        
                                        SMODS.change_play_limit(-pseudorandom('RANGE:1|3', 1, 3))
                                        return true
                                    end
                                })),
                                colour = G.C.WHITE,
                                extra = {
                                    
                                    G.E_MANAGER:add_event(Event({
                                        func = function()
                                            
                                            
                                            local current_shop_slots = (G.GAME.modifiers.shop_size or 0)
                                            local target_shop_slots = pseudorandom('RANGE:1|11', 1, 11)
                                            local difference = target_shop_slots - current_shop_slots
                                            change_shop_size(difference)
                                            return true
                                        end
                                    })),
                                    colour = G.C.WHITE,
                                    extra = {
                                        
                                        G.E_MANAGER:add_event(Event({
                                            func = function()
                                                
                                                
                                                SMODS.change_voucher_limit(pseudorandom('RANGE:1|4', 1, 4))
                                                return true
                                            end
                                        })),
                                        colour = G.C.WHITE,
                                        extra = {
                                            
                                            G.E_MANAGER:add_event(Event({
                                                func = function()
                                                    
                                                    
                                                    local current_booster_slots = (G.GAME.modifiers.extra_boosters or 0)
                                                    local target_booster_slots = pseudorandom('RANGE:0|5', 0, 5)
                                                    local difference = target_booster_slots - current_booster_slots
                                                    SMODS.change_booster_limit(difference)
                                                    return true
                                                end
                                            })),
                                            colour = G.C.WHITE,
                                            extra = {
                                                
                                                G.E_MANAGER:add_event(Event({
                                                    func = function()
                                                        G.GAME.round_resets.reroll_cost = G.GAME.round_resets.reroll_cost + pseudorandom('RANGE:2|5', 2, 5)
                                                        G.GAME.current_round.reroll_cost = math.max(0,
                                                            G.GAME.current_round.reroll_cost + pseudorandom('RANGE:2|5', 2, 5))
                                                            return true
                                                        end
                                                    }))
                                                    ,
                                                    colour = G.C.BLUE,
                                                    extra = {
                                                        func = function()
                                                            G.E_MANAGER:add_event(Event({
                                                                func = function()
                                                                    local selected_tag = pseudorandom_element(G.P_TAGS, pseudoseed("create_tag")).key
                                                                    local tag = Tag(selected_tag)
                                                                    if tag.name == "Orbital Tag" then
                                                                        local _poker_hands = {}
                                                                        for k, v in pairs(G.GAME.hands) do
                                                                            if v.visible then
                                                                                _poker_hands[#_poker_hands + 1] = k
                                                                            end
                                                                        end
                                                                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                                                    end
                                                                    tag:set_ability()
                                                                    add_tag(tag)
                                                                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                                                    return true
                                                                end
                                                            }))
                                                            return true
                                                        end,
                                                        message = "Created Tag!",
                                                        colour = G.C.GREEN
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        end
    }