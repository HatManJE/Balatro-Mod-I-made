
SMODS.Back {
    key = 'jesterful_deck',
    pos = { x = 0, y = 1 },
    config = {
        extra = {
            item_rate0 = 0,
            item_rate = 0,
            item_rate2 = 0,
            repetitions = 5
        },
    },
    loc_txt = {
        name = 'Jesterful Deck',
        text = {
            [1] = 'Start with 5 random eternal jesterful jokers, jokers no longer appear in the shop'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.joker_slots = 0
        G.GAME.common_mod = 0
        G.GAME.uncommon_mod = G.GAME.uncommon_mod -0
        G.GAME.rare_mod = 0
        G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots + 0
        for i = 1, 5 do
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'Joker', rarity = 'randombu_jesterful' })
                    if new_joker then
                        new_joker:add_sticker('eternal', true)
                    end
                    return true
                end
            }))
            
        end
    end
}