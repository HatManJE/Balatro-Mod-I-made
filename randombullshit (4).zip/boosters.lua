
SMODS.Booster {
    key = 'unknown_pack',
    loc_txt = {
        name = "Unknown Pack",
        text = {
            [1] = 'Select up to one of 5 consumables (Spectral cards, tarot, planets) to be used immeadietely'
        },
        group_name = "defaults_boosters"
    },
    config = { extra = 5, choose = 1 },
    cost = 9,
    weight = 0.3,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "defaults_boosters",
    draw_hand = true,
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            0.35,
            0.35,
            0.35
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('randombu_unknown_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
                set = "Planet",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "randombu_unknown_pack"
            }
        elseif selected_index == 2 then
            return {
                set = "Tarot",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "randombu_unknown_pack"
            }
        elseif selected_index == 3 then
            return {
                set = "Spectral",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "randombu_unknown_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("50e3c2"))
        ease_background_colour({ new_colour = HEX('50e3c2'), special_colour = HEX("9013fe"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'voucher_pack',
    loc_txt = {
        name = "Voucher pack",
        text = {
            [1] = 'Choose up to 1 of 5 vouchers to add to your run'
        },
        group_name = "randombu_boosters"
    },
    config = { extra = 5, choose = 1 },
    cost = 10,
    weight = 0.4,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    group_key = "randombu_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "randombu_voucher_pack"
        }
    end,
    particles = function(self)
        -- No particles for voucher packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'void_voucher',
        loc_txt = {
            name = "Void Voucher",
            text = {
                [1] = 'Todays your {C:attention}Lucky{} day.'
            },
            group_name = "randombu_boosters"
        },
        config = { extra = 10, choose = 10 },
        cost = 0,
        weight = 0.05,
        atlas = "CustomBoosters",
        pos = { x = 2, y = 0 },
        group_key = "randombu_boosters",
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            local weights = {
                0.5,
                1
            }
            local total_weight = 0
            for _, weight in ipairs(weights) do
                total_weight = total_weight + weight
            end
            local random_value = pseudorandom('randombu_void_voucher_card') * total_weight
            local cumulative_weight = 0
            local selected_index = 1
            for j, weight in ipairs(weights) do
                cumulative_weight = cumulative_weight + weight
                if random_value <= cumulative_weight then
                    selected_index = j
                    break
                end
            end
            if selected_index == 1 then
                return {
                    key = "soul",
                    set = "Tarot",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "randombu_void_voucher"
                }
            elseif selected_index == 2 then
                return {
                    key = "finalchance",
                    set = "Tarot",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "randombu_void_voucher"
                }
            end
        end,
        particles = function(self)
            G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                timer = 0.015,
                scale = 0.2,
                initialize = true,
                lifespan = 1,
                speed = 1.1,
                padding = -1,
                attach = G.ROOM_ATTACH,
                colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                fill = true
            })
            G.booster_pack_sparkles.fade_alpha = 1
            G.booster_pack_sparkles:fade(1, 0)
        end,
    }
    